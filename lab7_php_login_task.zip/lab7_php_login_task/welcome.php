<!DOCTYPE html>
<html lang="en">

<head> 
    <title> Welcome!! </title>    
    <meta charset="utf-8">
</head>

<body>


    <?php
        include 'header.inc';
        
        session_start();
        if (isset($_SESSION['user'])) {
            echo "Welcome, " .$_SESSION['user'];
        }   else {
            header('Location: login.html');
        }
        
    ?>
    <?php include 'footer.inc'; ?>
</body>

</html>