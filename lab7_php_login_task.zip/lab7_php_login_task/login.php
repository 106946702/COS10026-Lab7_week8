<!DOCTYPE html>
<html lang="en">
    <head>
	    <title> login page </title>
	    <meta charset="utf-8">
	    <meta name="description" content="Login Screen" >
    </head>

<body>
    <?php
        include 'header.inc';
    ?>

    <form method="post" action="process.php">
        <label for="username"> Pls enter username: </label>
        <input type="text" name="username" required> <br>
        
        <label for="password"> Pls enter password: </label>
        <input type="password" name="password" required> <br>

        <input type="hidden" name="surname + SwinID" value="106946702">
        <input type="submit" value ="Login">    
    </form>

    <?php
        include 'footer.inc';
    ?>

</body>

</html>