<!DOCTYPE html>
<html lang="en">

<head> 
    <title> login info </title>    
    <meta charset="utf-8">
</head>

<body>
    <header> <h1> Login Info </h1> </header>

    <?php
        session_start();
        $username = $_POST['username'];
        $password = $_POST['password'];

        if($username == 'Yau' && $password == '106946702') {
        $_SESSION['user'] = $username;
        header('Location:welcome.php');
        }   else    {
        echo "Invalid login. <a href='login.php'> Try Again </a>";
        }
    ?>

</body>

</html>